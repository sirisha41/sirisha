package com.bill.dao;

public interface IQueryMapper {
static final String GETCONSUMERDETAILS = "SELECT consumer_name,address FROM consumers where consumer_num=?";
static final String INSERTBILLDETAILS = "INSERT INTO billdetails values(bill_seq.nextval,?,?,?,?,SYSDATE)";
static final String GETDETAILS = "SELECT * FROM consumers";
static final String GETBILLDETAILS ="SELECT bill_num,to_char(bill_date,'month'),cur_reading,unitconsumed,netamount from billdetails where consumer_num=?";
}
