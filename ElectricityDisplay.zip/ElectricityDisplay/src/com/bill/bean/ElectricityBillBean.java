package com.bill.bean;

public class ElectricityBillBean {
private int billNumber;
private int consNumber;
private float lastMonMeterRead;
private float curMonMeterRead;
private float units;
private float netAmount;
private String Billmonth;
public String getBillmonth() {
	return Billmonth;
}
public void setBillmonth(String billmonth) {
	Billmonth = billmonth;
}
public int getBillNumber() {
	return billNumber;
}
public void setBillNumber(int billNumber) {
	this.billNumber = billNumber;
}
public int getConsNumber() {
	return consNumber;
}
public void setConsNumber(int consNumber) {
	this.consNumber = consNumber;
}
public float getLastMonMeterRead() {
	return lastMonMeterRead;
}
public void setLastMonMeterRead(float lastMonMeterRead) {
	this.lastMonMeterRead = lastMonMeterRead;
}
public float getCurMonMeterRead() {
	return curMonMeterRead;
}
public void setCurMonMeterRead(float curMonMeterRead) {
	this.curMonMeterRead = curMonMeterRead;
}
public float getUnits() {
	return units;
}
public void setUnits(float units) {
	this.units = units;
}
public float getNetAmount() {
	return netAmount;
}
public void setNetAmount(float netAmount) {
	this.netAmount = netAmount;
}

}
