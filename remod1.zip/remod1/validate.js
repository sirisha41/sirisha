function cust()
{

	var name=document.getElementById('cname').value;
	var mobile=document.getElementById('phone').value;
	var mail=document.getElementById('email').value;
	var address=document.getElementById('address').value;
	var city=document.getElementById('city').value;
	var amount=document.getElementById('amount').value;
	var win=window.open("","_blank","height=400,width=500");
	if(amount<2000)
	{
	discount=amount*0.2;
	}
	else
	{discount=amount*0.3;
	}
	win.document.writeln("<b><font color='red'>customer name"+name+"</font></b>");
	win.document.writeln("<br/>mobile number"+mobile);
	win.document.writeln("<br/>mail id"+mail);
	win.document.writeln("<br/>address"+address);
	win.document.writeln("<br/>city"+city);
	win.document.writeln("<br/>amount"+amount);
	win.document.writeln("<br/>discount"+discount);
}
	
	
	
	
	
	
	
	
	
	