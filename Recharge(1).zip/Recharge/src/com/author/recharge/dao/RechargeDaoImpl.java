package com.author.recharge.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.author.recharge.exception.RechargeException;

public class RechargeDaoImpl implements IRechargeDao{
	@Override
	public StringBuilder displayPlans() throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		StringBuilder s2=new StringBuilder("");
		java.sql.Statement s=conn.createStatement();
		try{
			String s1="select * from plans";
			ResultSet r=s.executeQuery(s1);
			if(r.next())
			{
				s2.append("plans      amount\n");
				s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
				while(r.next())
				{
					s2.append(r.getString(1)+"     "+r.getInt(2)+"\n");
				}
			}
			else
			{
				throw new RechargeException("please select valid plan");
			}
			return s2;
		}
		catch(RechargeException e)
		{
			s2.append(e.getMessage());
			return s2;
		}
	}

	@Override
	public int addUserDetails(String name,long mobile,String status,String planName,int amount) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		String s1="insert into rechargeInfo values(?,?,?,?,?,?)";
		PreparedStatement s=conn.prepareStatement(s1);
		String s2="select rec_seq.nextval from dual";
		java.sql.Statement sw=conn.createStatement();
		ResultSet r1=sw.executeQuery(s2);
		int val=0;
		while(r1.next())
		{
			val=r1.getInt(1);
		}
		s.setInt(1,val);
		s.setString(2,name);
		s.setLong(3, mobile);
		s.setString(4,status);
		s.setString(5,planName);
		s.setInt(6,amount);
		s.executeUpdate();
		return val;
	}
	@Override
	public StringBuilder retrieveUserDetails(int rechId) throws SQLException {
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		java.sql.Statement s=conn.createStatement();
		StringBuilder s2=new StringBuilder("");
		String s1="select * from rechargeInfo where rechargeId='"+rechId+"'";
		ResultSet r=s.executeQuery(s1);
			if(r.next())
			{
				s2.append("rech id"+r.getInt(1)+"\nname:"+r.getString(2)+"\nmobile:"+r.getLong(3)+"\nstatus:"+r.getString(4)
					+"\nplan name:"+r.getString(5)+"\namount:"+r.getInt(6));
			}
			return s2;
	}

	@Override
	public int retrieveAmount(String plan) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		String s1="select amount from plans where planName='"+plan+"'";
		java.sql.Statement s=conn.createStatement();
		int amount=0;
		ResultSet r=s.executeQuery(s1);
		while(r.next())
		{
			amount=r.getInt(1);
		}
		return amount;
	}

	@Override
	public boolean validPlan(String planName) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		String s1="select count(*) from plans where planName='"+planName+"'";
		java.sql.Statement s=conn.createStatement();
		ResultSet r=s.executeQuery(s1);
		int count=0;
		while(r.next())
		{
			count=r.getInt(1);
		}
		if(count==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean validRechId(int rechId) throws SQLException {
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1127","training1127");
		String s1="select count(*) from rechargeInfo where rechargeId='"+rechId+"'";
		java.sql.Statement s=conn.createStatement();
		ResultSet r=s.executeQuery(s1);
		int count=0;
		while(r.next())
		{
			count=r.getInt(1);
		}
		if(count==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
