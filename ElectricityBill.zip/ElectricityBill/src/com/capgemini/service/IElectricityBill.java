package com.capgemini.service;

import com.capgemini.bean.ElectricityBean;
import com.capgemini.dao.IElectricityDao;

public interface IElectricityBill {

	int addConsumerDetails(ElectricityBean bean);

	String isValidateConsumerNumber(int consumerNumber);

	
}
