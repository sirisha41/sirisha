package com.capgemini.service;

import com.capgemini.bean.ElectricityBean;
import com.capgemini.dao.ElectricityDaoImpl;
import com.capgemini.dao.IElectricityDao;

public class ElectricityBillImpl implements IElectricityBill{
	IElectricityDao dao;
	@Override
	public int addConsumerDetails(ElectricityBean bean) {
		dao=new ElectricityDaoImpl();
		int billId=dao.addConsumerDetails(bean);
		return billId;
		
	}

	@Override
	public String isValidateConsumerNumber(int consumerNumber) {
		dao=new ElectricityDaoImpl();
		String consumerName=dao.isValidateConsumerNumber(consumerNumber);
		// TODO Auto-generated method stub
		return consumerName;
		
	}

	
		
	}


