package com.capgemini.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.bean.ElectricityBean;

public class ElectricityDaoImpl implements IElectricityDao {

	@Override
	public int addConsumerDetails(ElectricityBean bean) {
		int billId=0;
		PreparedStatement pst;
		int query=0;
		try {
			
			InitialContext ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			//System.out.println("db Succesfully");
			int consumerNumber=bean.getConsumerNumber();
			pst=con.prepareStatement("Insert INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)");
			pst.setInt  (1,consumerNumber);
			//System.out.println(consumerNumber);
			pst.setFloat(2, bean.getCurrentMonthReading());
			pst.setFloat(3, bean.getUnitConsumed());
			pst.setFloat(4, bean.getNetAmount());
		    query=pst.executeUpdate();
		    if(query==1)
		    {
		    	System.out.println("Inserted in db Succesfully");
		    
		    }
		    else
		    	System.out.println("Not inserted");
		    pst= con.prepareStatement("SELECT seq_bill_num.CURRVAL FROM DUAL");
		    ResultSet rs=pst.executeQuery();
		    while(rs.next())
		    {
		    	billId=rs.getInt(1);
		    }
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return billId;
		
		
		
	}

	@Override
	public String isValidateConsumerNumber(int consumerNumber) {
		InitialContext ic;
		String consumerName = null;
		try {
			
			ic = new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
			Connection con=ds.getConnection();
			PreparedStatement pst=con.prepareStatement("Select consumer_name from consumers where consumer_num=?");
			pst.setInt(1,consumerNumber);
			ResultSet rs=pst.executeQuery();
			rs.next();
			consumerName=rs.getString("consumer_name");
			
			
		}   catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return consumerName;
		
	}

}
