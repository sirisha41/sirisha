package com.capgemini.dao;

import com.capgemini.bean.ElectricityBean;

public interface IElectricityDao {
	
	int addConsumerDetails(ElectricityBean bean);
	String isValidateConsumerNumber(int consumerNumber);
}
