package com.capgemini.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.bean.ElectricityBean;
import com.capgemini.service.ElectricityBillImpl;
import com.capgemini.service.IElectricityBill;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public LoginController() {
        super();
       
    }

	
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  
    	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   PrintWriter out=response.getWriter();
		   String operation=request.getParameter("action");
		   IElectricityBill service=new ElectricityBillImpl();
		   ElectricityBean bean=new ElectricityBean();
		   
		   if(operation!=null && operation.equals("login"))
		   {
		    String username=request.getParameter("username");
		    String password=request.getParameter("password");
		    if(username.equals("admin") && password.equals("admin"))
		    		{
		    	getServletContext().getRequestDispatcher("/consumerDetails.html").forward(request,response);
				
		    		}
		    else
		    	out.println("Invalid Username and password");
		   }
		   if(operation!=null && operation.equals("Calculate"))
		   {
			 int consumerNumber=Integer.parseInt(request.getParameter("consumerNumber")); 
			 float lastMonthReading=Float.parseFloat(request.getParameter("lastMonthReading"));
			 float currentMonthReading=Float.parseFloat(request.getParameter("currentMonthReading"));
			 String consumerName=service.isValidateConsumerNumber(consumerNumber);
			 if( consumerName!=null)
			 {
			 if(currentMonthReading >lastMonthReading)
			 {
				 float unitConsumed,netAmount,fixedCharge=100.0f;
				 unitConsumed=currentMonthReading-lastMonthReading;
				 netAmount=(float) ((unitConsumed*1.15)+fixedCharge);
				 bean.setConsumerNumber(consumerNumber);
				 bean.setLastMonthReading(lastMonthReading);
				 bean.setCurrentMonthReading(currentMonthReading);
				 bean.setUnitConsumed(unitConsumed);
				 bean.setNetAmount(netAmount);
				 int billId=service.addConsumerDetails(bean);
				 out.println("<h1> Welcome  "+consumerName+"<br/><h1/>"+"Your bill Id is  "+billId+"<br/>"+"Your Bill Amount is "+netAmount);
			 }
			 else
				 out.println("Current Month reading should be greater than last month Reading!!");
		   }
			 else
				 out.println("Invalid Consumer Number");
		
	}

}
}
