package com.cg.movieticketbooking.bean;

import java.sql.Connection;

public class MovieDetails {

	private String movie_id;

	public String getMovie_id() {
		return movie_id;
	}

	public void setMovie_id(String movie_id) {
		this.movie_id = movie_id;
	}

	public String getMovie_name() {
		return movie_name;
	}

	@Override
	public String toString() {
		return "MovieDetailsBean [movie_id=" + movie_id + ", movie_name="
				+ movie_name + ", theatre_name=" + theatre_name
				+ ", theatre_location=" + theatre_location + ", city=" + city
				+ ", show_timing=" + show_timing + ", status=" + status
				+ ", connection=" + connection + "]";
	}

	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}

	public String getTheatre_name() {
		return theatre_name;
	}

	public void setTheatre_name(String theatre_name) {
		this.theatre_name = theatre_name;
	}

	public String getTheatre_location() {
		return theatre_location;
	}

	public void setTheatre_location(String theatre_location) {
		this.theatre_location = theatre_location;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getShow_timing() {
		return show_timing;
	}

	public void setShow_timing(String show_timing) {
		this.show_timing = show_timing;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	private String movie_name;
	private String theatre_name;
	private String theatre_location;
	private String city;
	private String show_timing;
	private String status;
	private Connection connection;

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
}
