package com.cg.movieticketbooking.dao;

public interface IQueryMapper {
	String VIEW = "SELECT movie_id,movie_name,theatre_name,theatre_location,city,show_timing,status FROM movie_master WHERE city=?AND movie_name=?";
	String UPDATE = "UPDATE movie_master SET status=? WHERE movie_id=?";
}
