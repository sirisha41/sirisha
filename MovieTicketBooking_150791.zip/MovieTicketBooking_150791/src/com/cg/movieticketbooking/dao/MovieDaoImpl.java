package com.cg.movieticketbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.movieticketbooking.bean.MovieDetails;
import com.cg.movieticketbooking.exception.IExceptionMessage;
import com.cg.movieticketbooking.exception.MovieException;


public class MovieDaoImpl implements IMovieDAO {
	static Connection connection;
	ArrayList<MovieDetails> dlist = new ArrayList<MovieDetails>();
	PreparedStatement statement = null;
	@Override
	public ArrayList<MovieDetails> select(MovieDetails details)
			throws SQLException, MovieException {
		connection = details.getConnection();
		try{
		statement = connection.prepareStatement(IQueryMapper.VIEW);
		statement.setString(1,details.getCity());
		statement.setString(2,details.getMovie_name());
		ResultSet resultSet = statement.executeQuery();
		while(resultSet.next())
		{
			MovieDetails details1 = new MovieDetails();
			details1.setMovie_id(resultSet.getString(1));
			details1.setMovie_name(resultSet.getString(2));
			details1.setTheatre_name(resultSet.getString(3));
			details1.setTheatre_location(resultSet.getString(4));
			details1.setCity(resultSet.getString(5));
			details1.setShow_timing(resultSet.getString(6));
			details1.setStatus(resultSet.getString(7));
			dlist.add(details1);
			
		/*	details1.setTheatre_name(resultSet.getString(1));
			details1.setTheatre_location(resultSet.getString(2));
			details1.setShow_timing(resultSet.getString(3));
			
			details1.setStatus(resultSet.getString(4));*/
			//System.out.println(details1);
		}
		}
		 catch (Exception e) {
			
				throw new MovieException(IExceptionMessage.ERROR1);
			}
		return dlist;
	}

	@Override
	public int update(MovieDetails details) throws SQLException,MovieException{
int result=0;
		
		statement = connection.prepareStatement(IQueryMapper.UPDATE);
		statement.setString(1, "Not Available");
		statement.setString(2, details.getMovie_id());
		result=statement.executeUpdate();
		return result;
	}
		}
		