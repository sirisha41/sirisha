package com.cg.movieticketbooking.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.movieticketbooking.bean.MovieDetails;
import com.cg.movieticketbooking.exception.MovieException;


public interface IMovieDAO {
	public ArrayList<MovieDetails> select(MovieDetails details) throws SQLException, MovieException;
	public int update(MovieDetails details) throws SQLException, MovieException;
}
