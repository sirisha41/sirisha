package com.cg.movieticketbooking.exception;

public interface IExceptionMessage {
	String ERROR1 = "Error occurred.....";
}
