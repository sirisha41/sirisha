package com.cg.movieticketbooking.exception;

public class MovieException extends Exception {

	private static final long serialVersionUID = 1L;

	public MovieException() {
		// TODO Auto-generated constructor stub
	}

	public MovieException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
