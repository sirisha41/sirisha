package com.cg.movieticketbooking.service;

import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.movieticketbooking.bean.MovieDetails;
import com.cg.movieticketbooking.exception.MovieException;
public interface IMovieService {
	public ArrayList<MovieDetails> select(MovieDetails details) throws SQLException, MovieException;
	public int update(MovieDetails details) throws SQLException, MovieException;
}
