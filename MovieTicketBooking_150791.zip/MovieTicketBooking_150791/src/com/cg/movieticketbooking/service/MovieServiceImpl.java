package com.cg.movieticketbooking.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.movieticketbooking.bean.MovieDetails;
import com.cg.movieticketbooking.dao.IMovieDAO;
import com.cg.movieticketbooking.dao.MovieDaoImpl;
import com.cg.movieticketbooking.exception.MovieException;

public class MovieServiceImpl implements IMovieService{
	IMovieDAO dao = new MovieDaoImpl();
	@Override
	public ArrayList<MovieDetails> select(MovieDetails details)throws SQLException, MovieException {
		ArrayList<MovieDetails> list = new ArrayList<MovieDetails>();
		list = dao.select(details);
		return list;
	}
	@Override
	public int update(MovieDetails details) throws SQLException,MovieException {
		return dao.update(details);
	}
}
