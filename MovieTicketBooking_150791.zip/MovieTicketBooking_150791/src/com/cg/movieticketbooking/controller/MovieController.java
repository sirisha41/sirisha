package com.cg.movieticketbooking.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.cg.movieticketbooking.bean.MovieDetails;
import com.cg.movieticketbooking.service.IMovieService;
import com.cg.movieticketbooking.service.MovieServiceImpl;

@WebServlet("/MovieController")
public class MovieController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MovieDetails details = new MovieDetails();
	IMovieService service = new MovieServiceImpl();

	public MovieController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String city = request.getParameter("city");
		String movie = request.getParameter("movie");
		ArrayList<MovieDetails> list = new ArrayList<MovieDetails>();
		HttpSession session = request.getSession();
		session.setAttribute("city", city);
		session.setAttribute("movie", movie);
		try {
			details.setCity(city);
			details.setMovie_name(movie);

			request.setAttribute("city", city);
			request.setAttribute("movie", movie);
			InitialContext initialContext = new InitialContext();
			DataSource source = (DataSource) initialContext
					.lookup("java:/jdbc/OracleDS");
			Connection connection = source.getConnection();
			details.setConnection(connection);
			list = service.select(details);
			// request.setAttribute("list", list);
			session.setAttribute("list", list);
			getServletContext().getRequestDispatcher("/MovieDetails.jsp")
					.include(request, response);
			int result = 0;
			if (request.getParameter("button").equalsIgnoreCase("Book Now")) {
				String movieid = request.getParameter("id");
				details.setMovie_id(movieid);

				try {
					result = service.update(details);
				} catch (SQLException e) {
				}
				if (result != 1) {
					request.setAttribute("movieid", movieid);
					getServletContext().getRequestDispatcher("/Success.jsp")
							.forward(request, response);
				} else {
					getServletContext().getRequestDispatcher("/Failure.jsp")
							.forward(request, response);
				}
			}
		} catch (Exception e) {
		}
	}
}
