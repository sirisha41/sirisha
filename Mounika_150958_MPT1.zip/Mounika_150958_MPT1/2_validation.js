function validate(){
   
	var name = document.frmRegister.text.value;
	var phone=document.frmRegister.phone.value;
	var loan = document.frmRegister.amount.value;
        if(loan=="50,000 to 100000")
         var pay=1;
        else if(loan=="100001 to 200000")
         var pay=5;
        else if(loan=="200001 to 300000")
         var pay=10;
        else
        { 
         alert("please select loan amount to know payable duration");
          exit(0);
         }
        
	alert(" Thank you.   Your Name: "+name+"     Your mobile number: "+phone+"      Applied loan amount: "+loan+"       Payable duration :"+pay+" years");

}